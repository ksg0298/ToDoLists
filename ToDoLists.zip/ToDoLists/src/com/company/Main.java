package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    private static Scanner in= new Scanner(System.in);
    private static ToDoFunction myTodoList = new ToDoFunction();

    public static void main(String[] args) {
        int command = 0;
        boolean exit=false;
        printCommand();
        while(!exit){
            System.out.print("Enter ur choice");
            command= in.nextInt();
            in.nextLine();
            switch(command){
                case 0:
                    printCommand();
                    break;
                case 1:
                    myTodoList.printTodoList();
                    break;
                case 2:
                    addItem();
                    break;
                case 3:
                    updateItem();
                    break;
                case 4:
                    removeItem();
                    break;
                case 5:
                    searchItem();
                    break;
                case 6:
                    exit =true;
                    break;
                default:
                    System.out.print("Invalid Case");

            }
        }



    }
    public static void printCommand(){
        System.out.println("\n Commands:"+
                "\n Press 0 : to print instructions"+
                "\n Press 1 : to print the list"+
                "\n Press 2 : to add list to todo"+
                "\n Press 3 : to modify an item"+
                "\n Press 4 : to remove an item"+
                "\n Press 5 : to search an item from todo"+
                "\n Press 6 : to exit the app");
    }
    public static void addItem(){
        System.out.println("Enter item to be added: ");
        myTodoList.addItem(in.nextLine());
    }
    public static void updateItem() {
        System.out.println("Enter item no: ");
        int index = in.nextInt();
        in.nextLine();
        System.out.println("Enter new item to be added: ");
        String myNewInt = in.nextLine();
        myTodoList.updateTodo(index - 1, myNewInt);
    }
    public static void removeItem(){
        System.out.println("Enter item no: ");
        int index= in.nextInt();
        in.nextLine();
        myTodoList.removeItem(index-1);
    }
    public static void searchItem(){
        System.out.println("Enter a string to be searched: ");
        String searchItem = in.nextLine();
        if(myTodoList.findItem(searchItem)==null){
            System.out.println("item not found ");
        }else{
            System.out.println(searchItem+" was found in ur todo list ");
        }
    }
}
